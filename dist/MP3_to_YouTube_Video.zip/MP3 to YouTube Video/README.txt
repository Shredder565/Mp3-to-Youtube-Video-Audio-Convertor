MP3 to YouTube Video
====================

1. Keep "MP3 to YouTube Video.exe" and "ffmpeg.exe" in the same folder.
2. Double-click "MP3 to YouTube Video.exe".
   (If Windows SmartScreen warns, click "More info" -> "Run anyway".)
3. "Add MP3s..." (Ctrl/Shift-click to pick many) or "Add folder...".
4. Browse for your image (JPG/PNG - 1920x1080 looks best; other sizes
   get black bars).
5. Optionally pick a "Save to" folder. Leave blank to put each MP4
   next to its MP3.
6. Click Convert. Each song.mp3 becomes song.mp4 - 1080p H.264 + AAC,
   ready to upload to YouTube.

Fast mode (on by default) encodes the still picture at 2 frames/sec,
about 4x faster than 30 fps. Nothing is lost since the image never
changes, and YouTube accepts it. Untick it for a standard 30 fps file.
